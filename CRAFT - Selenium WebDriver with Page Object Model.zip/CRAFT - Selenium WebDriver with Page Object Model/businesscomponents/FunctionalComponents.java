package businesscomponents;

import com.cognizant.framework.Status;
import supportlibraries.ReusableLibrary;
import supportlibraries.ScriptHelper;
import pages.*;


/**
 * Functional Components class
 * @author Cognizant
 */
public class FunctionalComponents extends ReusableLibrary
{
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public FunctionalComponents(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
	}
	
	public void invokeApplication()
	{
		driver.get(properties.getProperty("ApplicationUrl"));
		report.updateTestLog("Invoke Application", "Invoke the application under test @ " +
								properties.getProperty("ApplicationUrl"), Status.DONE);
	}
	
	public void loginAsValidUser()
	{
		SignOnPage signOnPage = new SignOnPage(scriptHelper);
		signOnPage.loginAsValidUser();
		
		// The login succeeds if the flight finder page is displayed
		// Hence no further verification is required
		report.updateTestLog("Verify Login", "Login succeeded for valid user", Status.PASS);
	}
	
	public void loginAsInvalidUser()
	{
		SignOnPage signOnPage = new SignOnPage(scriptHelper);
		signOnPage = signOnPage.loginAsInvalidUser();
		
		// The login fails if the sign-on page is displayed again
		// Hence no further verification is required
		report.updateTestLog("Verify Login", "Login failed for invalid user", Status.PASS);
	}
	
	public void registerUser()
	{
		SignOnPage signOnPage = new SignOnPage(scriptHelper);
		UserRegistrationPage userRegistrationPage = signOnPage.clickRegister();
		userRegistrationPage.registerUser();
	}
	
	public void clickSignIn()
	{
		UserRegistrationConfirmationPage userRegistrationConfirmationPage =
									new UserRegistrationConfirmationPage(scriptHelper);
		userRegistrationConfirmationPage.clickSignIn();
	}
	
	public void findFlights()
	{
		FlightFinderPage flightFinderPage = new FlightFinderPage(scriptHelper);
		flightFinderPage.findFlights();
	}
	
	public void selectFlights()
	{
		SelectFlightPage selectFlightPage = new SelectFlightPage(scriptHelper);
		selectFlightPage.selectFlights();
	}
	
	public void bookFlights()
	{
		BookFlightPage bookFlightPage = new BookFlightPage(scriptHelper);
		bookFlightPage.bookFlights();
	}
	
	public void backToFlights()
	{
		FlightConfirmationPage flightConfirmationPage =
										new FlightConfirmationPage(scriptHelper);
		flightConfirmationPage.backToFlights();
	}
	
	public void logout()
	{
		FlightFinderPage flightFinderPage = new FlightFinderPage(scriptHelper);
		flightFinderPage.logout();
	}
}