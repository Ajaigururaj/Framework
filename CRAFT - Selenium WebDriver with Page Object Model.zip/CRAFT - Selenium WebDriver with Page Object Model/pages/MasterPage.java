package pages;

import org.openqa.selenium.By;

import com.cognizant.framework.Status;
import supportlibraries.*;


/**
 * MasterPage Abstract class
 * @author Cognizant
 */
abstract class MasterPage extends ReusableLibrary
{		
	/**
	 * Constructor to initialize the functional library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	protected MasterPage(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
	}
	
	public UserRegistrationPage clickRegister()
	{
		driver.findElement(By.linkText("REGISTER")).click();
		return new UserRegistrationPage(scriptHelper);
	}
	
	public SignOnPage logout()
	{
		driver.findElement(By.linkText("SIGN-OFF")).click();
		report.updateTestLog("Logout", "Click the sign-off link", Status.DONE);
		return new SignOnPage(scriptHelper);
	}
}