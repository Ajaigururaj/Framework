package pages;

import org.openqa.selenium.By;

import supportlibraries.*;

import com.cognizant.framework.Status;


/**
 * UserRegistrationPage class
 * @author Cognizant
 */
public class UserRegistrationPage extends MasterPage
{
	/**
	 * Constructor to initialize the page
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public UserRegistrationPage(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
		
		if(!driver.getTitle().contains("Register")) {
			throw new IllegalStateException("User Registration page expected, but not displayed!");
		}
	}
	
	public UserRegistrationConfirmationPage registerUser()
	{
		driver.findElement(By.name("firstName")).sendKeys(dataTable.getData("RegisterUser_Data","FirstName"));
		driver.findElement(By.name("lastName")).sendKeys(dataTable.getData("RegisterUser_Data","LastName"));		
		driver.findElement(By.name("phone")).sendKeys(dataTable.getData("RegisterUser_Data","Phone"));		
		driver.findElement(By.name("userName")).sendKeys(dataTable.getData("RegisterUser_Data","Email"));	
		driver.findElement(By.name("address1")).sendKeys(dataTable.getData("RegisterUser_Data","Address"));
		driver.findElement(By.name("city")).sendKeys(dataTable.getData("RegisterUser_Data","City"));
		driver.findElement(By.name("state")).sendKeys(dataTable.getData("RegisterUser_Data","State"));
		driver.findElement(By.name("postalCode")).sendKeys(dataTable.getData("RegisterUser_Data","PostalCode"));
		driver.findElement(By.name("email")).sendKeys(dataTable.getData("General_Data", "Username"));
		String password = dataTable.getData("General_Data", "Password");
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("confirmPassword")).sendKeys(password);
		driver.findElement(By.name("register")).click();
		report.updateTestLog("Registration", "Enter user details for registration", Status.DONE);
		
		return new UserRegistrationConfirmationPage(scriptHelper);
	}
}