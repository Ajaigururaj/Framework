package pages;

import org.openqa.selenium.By;

import supportlibraries.*;
import com.cognizant.framework.Status;


/**
 * FlightFinderPage class
 * @author Cognizant
 */
public class FlightFinderPage extends MasterPage
{
	/**
	 * Constructor to initialize the page
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public FlightFinderPage(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
		
		if(!driver.getTitle().contains("Find a Flight")) {
			throw new IllegalStateException("Find a Flight page expected, but not displayed!");
		}
	}
	
	public SelectFlightPage findFlights()
	{
		driver.findElement(By.name("passCount")).sendKeys((dataTable.getData("Passenger_Data", "PassengerCount")));
		driver.findElement(By.name("fromPort")).sendKeys((dataTable.getData("Flights_Data","FromPort")));
		driver.findElement(By.name("fromMonth")).sendKeys((dataTable.getData("Flights_Data","FromMonth")));
		driver.findElement(By.name("fromDay")).sendKeys((dataTable.getData("Flights_Data","FromDay")));
		driver.findElement(By.name("toPort")).sendKeys((dataTable.getData("Flights_Data","ToPort")));
		driver.findElement(By.name("toMonth")).sendKeys((dataTable.getData("Flights_Data","ToMonth")));
		driver.findElement(By.name("toDay")).sendKeys((dataTable.getData("Flights_Data","ToDay")));
		driver.findElement(By.name("airline")).sendKeys((dataTable.getData("Flights_Data","Airline")));
		driver.findElement(By.name("findFlights")).click();
		report.updateTestLog("Find Flights", "Search for flights using given test data", Status.DONE);
		
		return new SelectFlightPage(scriptHelper);
	}
}