package pages;

import org.openqa.selenium.By;

import supportlibraries.*;
import com.cognizant.framework.Status;


/**
 * SignOnPage class
 * @author Cognizant
 */
public class SignOnPage extends MasterPage
{	
	/**
	 * Constructor to initialize the page
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public SignOnPage(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
		
		if(!driver.getTitle().contains("Welcome") && !driver.getTitle().contains("Sign-on")) {
			throw new IllegalStateException("Sign-on page expected, but not displayed!");
		}
	}
	
	private void login()
	{
		String userName = dataTable.getData("General_Data", "Username");
		String password = dataTable.getData("General_Data", "Password");
		
		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
		report.updateTestLog("Login", "Enter login credentials: " +
											"Username = " + userName + ", " +
											"Password = " + password, Status.DONE);
	}
	
	public FlightFinderPage loginAsValidUser()
	{	
		login();
		return new FlightFinderPage(scriptHelper);
	}
	
	public SignOnPage loginAsInvalidUser()
	{	
		login();
		return new SignOnPage(scriptHelper);
	}
}