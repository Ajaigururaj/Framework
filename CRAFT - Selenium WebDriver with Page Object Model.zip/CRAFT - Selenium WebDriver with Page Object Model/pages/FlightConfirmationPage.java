package pages;

import org.openqa.selenium.By;

import supportlibraries.*;


/**
 * FlightConfirmationPage class
 * @author Cognizant
 */
public class FlightConfirmationPage extends MasterPage
{
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public FlightConfirmationPage(ScriptHelper scriptHelper)
	{
		super(scriptHelper);
		
		if(!driver.getTitle().contains("Flight Confirmation")) {
			throw new IllegalStateException("Flight Confirmation page expected, but not displayed!");
		}
	}
	
	public FlightFinderPage backToFlights()
	{
		driver.findElement(By.xpath("//a/img")).click();
		return new FlightFinderPage(scriptHelper);
	}
}